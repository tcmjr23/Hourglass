import java.util.Scanner;

/*Troy Mosqueda
 *Prints an hourglass
 *October 14, 2022
 *Draft 1: 1:15 a.m. finished (used multiple print statements)
 *Final Revision: 7:44 p.m. 
 */
public class Hourglass{
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);;
		System.out.print("Enter hourglass size: ");
		int size = input.nextInt();
		
		
		System.out.print(base(size));
		System.out.print(elapseTop(size));
		System.out.print(midsection(size));
		System.out.print(elapseBottom(size));
		System.out.print(base(size));
		input.close();	
	}
	public static String base(int n) {
		String base = "";
		for (int i = 0;i < n; i++) {
			base += "\"";
		}
		return "|" + base + "|";
		
	}
	
	public static String elapseTop(int n) {
		String sand;
		int white = 0;
		for(int i = 0; i <n/2-1; i++) { 
			System.out.println();	
			white+=1;
			for(int p = 0; p<white;p++) {
				System.out.print(" ");
			}	
			sand = "";
			for(int j = 0; j<n-(2*(i+1)); j++){
				sand += ":";
				
			}
			System.out.print("\\" + sand + "/");
		}return "";
	}
		
	public static String midsection(int n) {
		System.out.println();
		if (n%2==1) {
			System.out.print("");
		}
		for(int i = 0; i<n/2; i++) {
			System.out.print(" ");
		}
		if (n%2==0) {
		System.out.print("||");
		}else {
			System.out.print("| |");
		}
		return "";
	}
	
	
	
	public static String elapseBottom(int n) {
		int white = n/2-1;
		String sand;
		for(int i = 0; i<n/2-1; i++){
			System.out.println();
			for (int k = 0; k < white; k++) {
				System.out.print(" ");  
			}			
			white-=1;
			sand = "";
			for(int j = n-(2*(i+1)); j<n; j++){     
				sand += ":";
			} 
			if(n%2!=0) {
				sand += ":";
				
				
			}
			System.out.print("/" + sand + "\\");
		}
		return "\n";
		
	}
		
		
}